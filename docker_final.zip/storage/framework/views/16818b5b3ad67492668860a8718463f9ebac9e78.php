
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="<?php echo e(route('customer.update', $customer->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="card-body">
            <div class="form-group">
                <label for="name">Tên</label>
                <input type="text" name="name" class="form-control" id="name" value="<?php echo e($customer->name); ?>" placeholder="Enter name...">
            </div>

            <div class="form-group">
                <label for="address">Địa chỉ</label>
                <input type="text" name="address" class="form-control" id="address" value="<?php echo e($customer->address); ?>" placeholder="Enter address...">
            </div>
            
            <div class="form-group">
                <label for="phone">Số điện thoại</label>
                <input type="text" name="phone" value="<?php echo e($customer->phone); ?>" class="form-control" id="phone">
            </div>

            <div class="form-group">
                <label for="birthday">Ngày sinh</label>
                <input type="date" name="birthday" value="<?php echo e($customer->birthday); ?>" class="form-control" id="birthday">
            </div>
            
        <!-- /.card-body -->
        <div class="card-footer">
            <button type="submit" class="btn text-light" style="background-image: linear-gradient(to right, black, rgb(93, 64, 220));">Sửa thông tin khách hàng</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/customers/show.blade.php ENDPATH**/ ?>