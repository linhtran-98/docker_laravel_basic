
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card-header">
    <a href="<?php echo e(route('customer.create')); ?>" class="btn text-light" style="background-image: linear-gradient(to right, black, rgb(93, 64, 220));">Thêm mới khách hàng</a>
</div>
<div class="card">
    <div class="card-body">
      <table class="table table-bordered">
        <thead>
          <tr class="text-center">
            
            <th>Tên khách hàng</th>
            <th>Địa chỉ</th>
            <th>Số điện thoại</th>
            <th>Ngày sinh</th>
            <th>Ngày tạo</th>
            <th>Ngày cập nhật</th>
            <th colspan="2">Thao tác</th>
            
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center">
              
              <td class="font-weight-bold" style="color:rgb(93, 64, 220);"><?php echo e($value->name); ?></td>
              <td><?php echo e($value->address); ?></td>
              <td class="font-weight-bold" style="color:rgb(93, 64, 220);"><?php echo e($value->phone); ?></td>
              <td><?php echo e($value->birthday); ?></td>
              <td><?php echo e($value->created_at); ?></td>
              <td><?php echo e($value->updated_at); ?></td>
              <td class="text-center"><a class="btn text-light" style="background-image: linear-gradient(to right, black, rgb(93, 64, 220));" href="<?php echo e(route('customer.edit', $value->id)); ?>">Sửa</a></td>
              <td class="text-center">
                <form id="deleteForm" action="<?php echo e(route('customer.destroy', $value->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <input type="submit" class="btn text-light" style="background-image: linear-gradient(to right, black, rgb(188, 36, 79));" value="Xóa">
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <!-- /.card-body -->
    <div class="card-footer clearfix">
      <div class="pagination pagination-sm m-0">
        <?php echo e($customers->appends($_GET)->links()); ?>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/customers/index.blade.php ENDPATH**/ ?>